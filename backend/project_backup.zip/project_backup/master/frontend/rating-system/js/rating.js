function ratingSystem(type, location, postId) {

    $.ajax({
        type: 'POST',
        url: 'rating-system/rating-config.php',
        data: {
            type: type,
            postId: postId
        },
        success: function (data) {
            if (data == 'err') {
                alert('Some problem occured, please try again.');
            } else {
                console.log('AJAX sent -> ' + data);
                $('#'+ location + postId).hide().html(data).fadeIn(1000);
            }
        }
    });
}

