<?php

include("db-config.php");

$ajaxPostType = $_POST['type'] ?? ''; // ?? '' is a Null Coalesce Operator, which fixes "Notice: Undefined variable" error.

if ($ajaxPostType == 1) {
  addUpvote();
}

if ($ajaxPostType == 2) {
  addDownvote();
}

function displayUpvote($postId)
{
  
  include("db-config.php");
  $selectQuery = "SELECT upvote FROM posts WHERE post_id = $postId";

  $selectQueryResult = mysqli_query($dbConnection, $selectQuery);
  if (!$selectQueryResult) {
    mysqli_close($dbConnection);
    throw new Exception(mysqli_error($dbConnection));
  }

  $upvote = mysqli_fetch_assoc($selectQueryResult);
  mysqli_close($dbConnection);

  return $upvote;
}

function displayDownvote($postId)
{
  include("db-config.php");
  $selectQuery = "SELECT downvote FROM posts WHERE post_id = $postId";

  $selectQueryResult = mysqli_query($dbConnection, $selectQuery);
  if (!$selectQueryResult) {
    mysqli_close($dbConnection);
    throw new Exception(mysqli_error($dbConnection));
  }

  $downvote = mysqli_fetch_assoc($selectQueryResult);
  mysqli_close($dbConnection);

  return $downvote;
}

function addUpvote()
{
  $postId = $_POST['postId'];

  $updateQuery = "UPDATE posts SET upvote = (upvote + 1) WHERE post_id = $postId";
  include("db-config.php");

  if (!mysqli_query($dbConnection, $updateQuery)) {
    die('Error' . mysqli_error($dbConnection));
  } else {
    $selectQuery = "SELECT upvote FROM posts WHERE post_id = $postId";
    $selectQueryResult = mysqli_query($dbConnection, $selectQuery);

    $upvote = mysqli_fetch_assoc($selectQueryResult);
    foreach ($upvote as $upvote) {
      echo ("Upvotes: $upvote");
    }
  }
  mysqli_close($dbConnection);
}

function addDownvote()
{
  $postId = $_POST['postId'];
  
  $updateQuery = "UPDATE posts SET downvote = (downvote + 1) WHERE post_id = $postId";
  include("db-config.php");

  if (!mysqli_query($dbConnection, $updateQuery)) {
    die('Error' . mysqli_error($dbConnection));
  } else {
    $selectQuery = "SELECT downvote FROM posts WHERE post_id = $postId";
    $selectQueryResult = mysqli_query($dbConnection, $selectQuery);

    $downvote = mysqli_fetch_assoc($selectQueryResult);
    foreach ($downvote as $downvote) {
      echo ("Downvotes: $downvote");
    }
  }
  mysqli_close($dbConnection);
}

